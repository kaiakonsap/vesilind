
	</div>

	<footer class="footer centeralign bluebg">
			<div class="coyright inlineblock white"><?php  echo get_theme_mod( 'footer_text', 'Muuda seda teksti Välimus -> Kohanda alt' );?></div>
  <div class="facebook inlineblock white"><a class="white" href="<?php  echo get_theme_mod( 'footer_facebook', '#' );?>"><i class="fa fa-facebook" aria-hidden="true"></i></a></div>

	</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>
