jQuery(document).ready(function() {

  jQuery('.cboxElement').click(function(event){

    event.preventDefault();
alert(jQuery(this).attr('rel'));
    jQuery.colorbox({
      open :true,
        maxWidth: '90%',
        closeButton:true,
        speed: 700,
        rel: jQuery(this).attr('rel')
    });
});
})
