
	</div>

	<footer class="footer centeralign blackbg">
			<div class="coyright inlineblock white"><?php  echo get_theme_mod( 'footer_text', 'Muuda seda teksti Välimus -> Kohanda alt' );?></div>
  <div class="facebook inlineblock white"><a target="_blank" class="white" href="<?php  echo get_theme_mod( 'footer_facebook', '#' );?>"><i class="fa fa-facebook white" aria-hidden="true"></i></a></div>

	</footer>

</div>

<?php wp_footer(); ?>

</body>
</html>
